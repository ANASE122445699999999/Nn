const express = require('express');

const app = express();

app.get('/', (req, res) => {
  res.send('Hello Express app!')
});

app.listen(3000, () => {
  console.log('server started');
});

// استدعاء discord.js
const { Client, GatewayIntentBits, ButtonStyle, EmbedBuilder, ActionRowBuilder, ButtonBuilder, Events, ModalBuilder, PermissionsBitField, ActivityType, TextInputBuilder, TextInputStyle, RoleSelectMenuBuilder, ComponentType, ChannelSelectMenuBuilder, ChannelType, Collector, SelectMenuOptionBuilder, Message } = require('discord.js')
const { StringSelectMenuBuilder, StringSelectMenuOptionBuilder, SlashCommandBuilder , PermissionOverwriteManager , PermissionOverwrites  } = require('discord.js');
// تعريف ال Client
const client = new Client({
  intents: [Object.keys(GatewayIntentBits)]
})

process.on("uncaughtException" , err => {
    return;
    })

    process.on("unhandledRejection" , err => {
    return;
    })

    process.on("rejectionHandled", error => {
      return;
    });


const db = require("pro.db")
// تعديل مهم
client.on("ready", () => {
  console.log(`Logged in as ${client.user.tag} online`);
  client.user.setActivity('هويات ', { type: ActivityType.Watching });
  client.user.setStatus("dnd")
});

const prefix = "-"
client.on("messageCreate" , msg => {
    if (msg.content.startsWith(prefix + "create-user")){
        let row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setLabel("إنشاء هوية").setStyle(ButtonStyle.Primary).setCustomId("click")
        )

        let e = new EmbedBuilder()
        .setColor("White")
        .setAuthor({ name : msg.author.tag , iconURL : msg.author.avatarURL()})
        .setTimestamp()
        .setDescription("هوية جديدة \n الزر سيختفني بعد دقيقه !")
        msg.author.send({embeds : [e] , components : [row]}).then((a) => {
        setTimeout(async() => {
 await a.delete({embeds : [e] , components : []})
        } , 60000)
    })

    }
})
client.on("interactionCreate" ,async  i => {
    if (i.customId == "click"){
        const modal = new ModalBuilder()
        .setCustomId("questions")
        .setTitle("اسئلة انشاء هوية ")

        const ques1 = new TextInputBuilder()
.setCustomId("name")
.setStyle(TextInputStyle.Short)
.setLabel("الاسم")
.setRequired(true)
const ques2 = new TextInputBuilder()
.setCustomId("time_born")
.setStyle(TextInputStyle.Short)
.setLabel("تاريخ الميلاد")
.setRequired(true)
const ques3 = new TextInputBuilder()
.setCustomId("location")
.setStyle(TextInputStyle.Short)
.setLabel("مكان الميلاد")
.setRequired(true)
const ques4 = new TextInputBuilder()
.setCustomId("job")
.setStyle(TextInputStyle.Short)
.setLabel("الوظيفة")
.setRequired(true)
const ques5 = new TextInputBuilder()
.setCustomId("id")
.setStyle(TextInputStyle.Short)
.setLabel("البلايستيشن ايدي")
.setRequired(true)

const R1 = new ActionRowBuilder().addComponents(ques1)
const R2 = new ActionRowBuilder().addComponents(ques2)
const R3 = new ActionRowBuilder().addComponents(ques3)
const R4 = new ActionRowBuilder().addComponents(ques4)
const R5 = new ActionRowBuilder().addComponents(ques5)
  modal.addComponents(R1 , R2 , R3 , R4 , R5)
 await i.showModal(modal)

    }
})

client.on("interactionCreate" ,async  i => {
    if (!i.isModalSubmit()) return;

    if (i.customId == "questions"){
      const name = i.fields.getTextInputValue("name")
      const words = name.split(/\s+/)
      if (words.length > 5) {
        return i.reply(`** الرجاء كتابه اسم ثلاثي على الاقل وخماسي كحد اقصى**`)
      }
      if (words.length < 3) {
        return i.reply(`** الرجاء كتابه اسم ثلاثي على الاقل وخماسي كحد اقصى**`)
      }
      const tp = i.fields.getTextInputValue("time_born")
      const time = tp.split("/")
      const datte = (`${time[2]}${time[1]}${time[0]}`)
if (isNaN(datte)){
  return i.reply(`يجب عليك كتابه تاريخ الميلاد بصورة صحيحة 
  مثال : \` 1992\\12\\31 \``)
}
      const newdate = (`${time[2]}-${time[1]}-${time[0]}`)

      const location = i.fields.getTextInputValue("location")
      if (location !== "لوس سانتوس" && location !== "بوليتو" && location !== "ساندي شور")
      {
          return i.reply(`❌ يجب عليك تحديد احد المدن الاتيه : \n\n \`ساندي شور , بوليتو , لوس سانتوس \``)
      }
      const job = i.fields.getTextInputValue("job")
      const id = i.fields.getTextInputValue("id")
      const select = new StringSelectMenuBuilder()
      .setCustomId("5hselect2")
      .setPlaceholder("يرجى الاختيار")
      .addOptions(
        new StringSelectMenuOptionBuilder()
        .setLabel("ذكر")
        .setValue("male"),
        new StringSelectMenuOptionBuilder()
        .setLabel("انثى")
        .setValue("female")
      )
      const row = new ActionRowBuilder().addComponents(select)
await i.deferUpdate() 
await i.editReply({components : [row] , embeds : []}) 


db.set(`${i.user.id}` , {
  name,
  newdate,
  location,
  job,
  id,
  attachments : "",
  male : false,
  female : false,
})
 }
   })
   client.on("interactionCreate" ,async i => {
    if (i.values == "male"){
      const user = i.user.id
const data = db.get(user)
data.male = true

db.set(user , data)
const select = new StringSelectMenuBuilder()
.setCustomId("select")
.setPlaceholder("يرجى اختيار رقم الشخصية")
.addOptions(
  new StringSelectMenuOptionBuilder()
  .setLabel("Character 1")
  .setDescription("كاركتر رقم 1")
  .setValue("1"),
  new StringSelectMenuOptionBuilder()
  .setLabel("Character 2")
  .setDescription("كاركتر رقم 2")
  .setValue("2"),
  new StringSelectMenuOptionBuilder()
  .setLabel("Character 3")
  .setDescription("كاركتر رقم 3")
  .setValue("3")
)
const row = new ActionRowBuilder().addComponents(select)
await i .deferUpdate()
await i.editReply({components : [row]})



}else if(i.values == "female"){
      const user = i.user.id
      const data = db.get(user)
      data.female = true
      db.set(user , data)
      const select = new StringSelectMenuBuilder()
.setCustomId("select")
.setPlaceholder("يرجى اختيار رقم الشخصية")
.addOptions(
  new StringSelectMenuOptionBuilder()
  .setLabel("Character 1")
  .setDescription("كاركتر رقم 1")
  .setValue("1"),
  new StringSelectMenuOptionBuilder()
  .setLabel("Character 2")
  .setValue("2"),
  new StringSelectMenuOptionBuilder()
  .setLabel("Character 3")
  .setValue("3")
)
const row = new ActionRowBuilder().addComponents(select)
await i .deferUpdate()
await i.editReply({components : [row]})
const id = i.user.id
}
})

client.on("interactionCreate" , async i => {
  const user = i.user.id;
  if (i.customId == "select"){
    db.set(`s_${i.user.id}` , i.values[0])
    const data = db.get(i.user.id)
    let channelID = "1217938554672517170"
    const guild = client.guilds.cache.get("1203883850514825246")
    let channel = guild.channels.cache.get(channelID)
let embed1 = new EmbedBuilder().setColor("DarkButNotBlack").setTitle("Character Created")

.setDescription(` Name : ${data.name}

Date : ${data.newdate}

Place : ${data.location}

Job : ${data.job}

Sex : Male

Character Number : ${i.values[0]}`)

let embed2 = new EmbedBuilder().setColor("DarkButNotBlack").setTitle("Character Created")
.setDescription(` Name : ${data.name}

Date : ${data.newdate}

Place : ${data.location}

Job : ${data.job}

Sex : Female

Character Number : ${i.values[0]}`)

let row3 = new ActionRowBuilder().addComponents(
  new ButtonBuilder().setLabel("Accept").setStyle(ButtonStyle.Primary).setCustomId("Accept"),
  new ButtonBuilder().setLabel("Regect").setStyle(ButtonStyle.Danger).setCustomId("Regect")
)
    i.user.send({content : "الرجاء ارفاق صورة الكركتر" , components : []}).then(async (msg) => {
      const collector = msg.channel.createMessageCollector({ max: 1, time: 25000})
      collector.on('collect', async m => {
        const image = m.attachments.first() ? m.attachments.first().url.toString() : m.content.toString();

collector.on("end" , msg =>{
  data.attachments = image
  const user = i.user.id;
  db.set(user , data)
  db.set(`Character_${i.values[0]}_${user}` , data)

  i.user.send("تم الانتهاء من التقديم")

  let embed1 = new EmbedBuilder().setColor("DarkButNotBlack").setTitle("Character Created")
.setThumbnail(data.attachments)
  .setDescription(` Name : ${data.name}

  Date : ${data.newdate}

  Place : ${data.location}

  Job : ${data.job}

  Sex : Male

  Character Number : ${i.values[0]}`)

  let embed2 = new EmbedBuilder().setColor("DarkButNotBlack").setTitle("Character Created")
  .setThumbnail(data.attachments)

  .setDescription(` Name : ${data.name}

  Date : ${data.newdate}

  Place : ${data.location}

  Job : ${data.job}

  Sex : Female

  Character Number : ${i.values[0]}`)

  let row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setLabel("Accept").setStyle(ButtonStyle.Primary).setCustomId("Accept"),
    new ButtonBuilder().setLabel("Regect").setStyle(ButtonStyle.Danger).setCustomId("Regect")
  ) 
  let row4 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setLabel("Accept").setStyle(ButtonStyle.Primary).setCustomId("Accepts"),
    new ButtonBuilder().setLabel("Regect").setStyle(ButtonStyle.Danger).setCustomId("Regect")
  )
  if (data.male === true ){
    channel.send({embeds : [embed1] , components : [row3] , content : `${user}`})

  }else if (data.female === true) {
    channel.send({embeds : [embed2] , components : [row3] , content : `${user}`})

  }

})
})
    })



  }else if (i.customId == "Accept"){
const userId = i.message.content;
const user = i.guild.members.cache.get(userId)
    let role_1 = "1216913012859080774"
    let role_2 = "1216913012859080774"
    let role_3 = "1216913012859080774"
    const role1 = i.guild.roles.cache.get(role_1)
    const role12 = i.guild.roles.cache.get(role_2)
    const role3 = i.guild.roles.cache.get(role_3)

    if (db.has(`Character_1_${userId}`)){
      i.guild.members.cache.get(userId).roles.add(`${role_1}`)  
    }else if (db.has(`Character_2_${userId}`)){
      i.guild.members.cache.get(userId).roles.add(`${role_2}`)  
    }else if (db.has(`Character_3_${userId}`)){
      i.guild.members.cache.get(userId).roles.add(`${role_3}`)  
    }

  const r = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel("Accepted").setStyle(ButtonStyle.Primary).setCustomId("Accept").setDisabled(true)
      )
      db.delete(`s_${userId}`)

    await i.deferUpdate()
    await i.editReply({components : [r] })
    user.send(`** تم قبول تقديم الكاركتر الخاص بك**`)
  }else if (i.customId == "Regect"){
    const userId = i.message.content;
    const user = i.guild.members.cache.get(userId)
    const selected22 = db.get(`s_${userId}`)

  const r = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel("Regected").setStyle(ButtonStyle.Danger).setCustomId("Accept").setDisabled(true)
      )
    await i.deferUpdate()
    await i.editReply({components : [r]})
    user.send(`** تم رفض تقديم الكاركتر الخاص بك**`)
db.delete(`Character_${selected22}_${userId}`)
 db.delete(`s_${userId}`)

  }else if (i.customId == "Accepts"){
    const userId = i.message.content;
    const user = i.guild.members.cache.get(userId)

    if (i.member.roles.cache.has("1216913012859080774"))return;
            let role_3 = "1216913012859080774"

            const role3 = i.guild.roles.cache.get(role_3)
            const userM = i.guild.members.cache.get(user)

            if (db.has(`Character_1_${userId}`)){
              i.guild.members.cache.get(userId).roles.add(`${role_1}`)  
            }else if (db.has(`Character_2_${userId}`)){
              i.guild.members.cache.get(userId).roles.add(`${role_2}`)  
            }else if (db.has(`Character_3_${userId}`)){
              i.guild.members.cache.get(userId).roles.add(`${role_3}`)  
            }
          }
        })



client.on("messageCreate" , msg => {
  if (msg.content.startsWith(prefix + "edit-profile")){
    const User =  msg.mentions.members.first() || msg.author.id;
    if (msg.author.bot)return;

    if (!db.has(User)){
      return msg.reply("❌ انت لا تمتلك كاركترات")
    }
    const embed = new EmbedBuilder().setColor("White")
    .setTimestamp()
    .setDescription("** الرجاء اختيار رقم الكاركتر الذي تريد تعديله**")
    const nenu = new StringSelectMenuBuilder()
    .setCustomId("select3")
    .setPlaceholder("اضغط هنا ")
    .addOptions(
      new StringSelectMenuOptionBuilder()
      .setLabel("Character 1")
      .setDescription("كاركتر رقم 1")
      .setValue("-1-"),
      new StringSelectMenuOptionBuilder()
      .setLabel("Character 2")
      .setDescription("كاركتر رقم 2")
      .setValue("-2-"),
      new StringSelectMenuOptionBuilder()
      .setLabel("Character 3")
      .setDescription("كاركتر رقم 3")
      .setValue("-3-")
    )
    const row = new ActionRowBuilder().addComponents(nenu)
    msg.reply({embeds : [embed] , components : [row]})
  }
})
    client.on("interactionCreate" , async i => {
      if (!i.isSelectMenu())return
      if (i.values[0] === "-1-"){
        const data = db.get(`Character_1_${i.user.id}`)
        if (!data)return i.reply({content : `❌ انت لا تمتلك كاركتر رقمه 1` , ephemeral : true})
        const emb = new EmbedBuilder().setColor("DarkButNotBlack").setTimestamp().setThumbnail(i.user.avatarURL())
     .setTitle(`Character 1`)
     .setDescription(` ** الرجاء اختيار نوع التعديل**`)
     const select2 = new StringSelectMenuBuilder()
     .setCustomId("edit-type")
     .setPlaceholder("select edit Type")
     .addOptions(
      new StringSelectMenuOptionBuilder()
      .setLabel("الأســم")
      .setDescription(`لتعديل الاسم الخاص بالكاركتر رقم 1 اضغط هنا`)
      .setValue(`new-name1`),
      new StringSelectMenuOptionBuilder()
      .setLabel("تــاريـخ الــولادة")
      .setDescription(`لتعديل تاريخ الولادة الخاص بالكاركتر رقم 1 اضغط هنا`)
      .setValue("new-date1"),
      new StringSelectMenuOptionBuilder()
      .setLabel("مــكـان الــولادة")
      .setDescription(`لتعديل مكان الولادة الخاص بالكاركتر رقم 1 اضغط هنا`)
      .setValue("new-location1"),
      new StringSelectMenuOptionBuilder()
      .setLabel("الــوظـيفـة")
      .setDescription(`لتعديل الوظيفة الخاصة بالكاركتر رقم 1 اضغط هنا`)
      .setValue("new-job1"),
      new StringSelectMenuOptionBuilder()
      .setLabel("ايــدي الـبـلايـسـيـشن")
      .setDescription(`لتعديل ايدي البلايستيشن الخاص بالكاركتر رقم 1 اضغط هنا`)
      .setValue("new-id1")
     )
     const r2 = new ActionRowBuilder().addComponents(select2)
     await i.deferUpdate()
     await i.editReply({components : [r2] , embeds : [emb]})
      }else if (i.values[0] === "-2-"){
        const data = db.get(`Character_2_${i.user.id}`)
        if (!data)return i.reply({content : `❌ انت لا تمتلك كاركتر رقمه 2` , ephemeral : true})
        const emb = new EmbedBuilder().setColor("DarkButNotBlack").setTimestamp().setThumbnail(i.user.avatarURL())
     .setTitle(`Character 2`)
     .setDescription(` ** الرجاء اختيار نوع التعديل**`)
     const select2 = new StringSelectMenuBuilder()
     .setCustomId("edit-type")
     .setPlaceholder("select edit Type")
     .addOptions(
      new StringSelectMenuOptionBuilder()
      .setLabel("الأســم")
      .setDescription(`لتعديل الاسم الخاص بالكاركتر رقم 2 اضغط هنا`)
      .setValue(`new-name2`),
      new StringSelectMenuOptionBuilder()
      .setLabel("تــاريـخ الــولادة")
      .setDescription(`لتعديل تاريخ الولادة الخاص بالكاركتر رقم 2 اضغط هنا`)
      .setValue("new-date2"),
      new StringSelectMenuOptionBuilder()
      .setLabel("مــكـان الــولادة")
      .setDescription(`لتعديل مكان الولادة الخاص بالكاركتر رقم 2 اضغط هنا`)
      .setValue("new-location2"),
      new StringSelectMenuOptionBuilder()
      .setLabel("الــوظـيفـة")
      .setDescription(`لتعديل الوظيفة الخاصة بالكاركتر رقم 2 اضغط هنا`)
      .setValue("new-job2"),
      new StringSelectMenuOptionBuilder()
      .setLabel("ايــدي الـبـلايـسـيـشن")
      .setDescription(`لتعديل ايدي البلايستيشن الخاص بالكاركتر رقم 2 اضغط هنا`)
      .setValue("new-id2")
     )
     const r2 = new ActionRowBuilder().addComponents(select2)
     await i.deferUpdate()
     await i.editReply({components : [r2] , embeds : [emb]})

      }else if (i.values[0] === "-3-"){
        const data = db.get(`Character_3_${i.user.id}`)
if (!data)return i.reply({content : `❌ انت لا تمتلك كاركتر رقمه 3` , ephemeral : true})
        const emb = new EmbedBuilder().setColor("DarkButNotBlack").setTimestamp().setThumbnail(i.user.avatarURL())
     .setTitle(`Character 3`)
     .setDescription(` ** الرجاء اختيار نوع التعديل**`)
     const select2 = new StringSelectMenuBuilder()
     .setCustomId("edit-type")
     .setPlaceholder("select edit Type")
     .addOptions(
      new StringSelectMenuOptionBuilder()
      .setLabel("الأســم")
      .setDescription(`لتعديل الاسم الخاص بالكاركتر رقم 3 اضغط هنا`)
      .setValue(`new-name3`),
      new StringSelectMenuOptionBuilder()
      .setLabel("تــاريـخ الــولادة")
      .setDescription(`لتعديل تاريخ الولادة الخاص بالكاركتر رقم 3 اضغط هنا`)
      .setValue("new-date3"),
      new StringSelectMenuOptionBuilder()
      .setLabel("مــكـان الــولادة")
      .setDescription(`لتعديل مكان الولادة الخاص بالكاركتر رقم 3 اضغط هنا`)
      .setValue("new-location3"),
      new StringSelectMenuOptionBuilder()
      .setLabel("الــوظـيفـة")
      .setDescription(`لتعديل الوظيفة الخاصة بالكاركتر رقم 3 اضغط هنا`)
      .setValue("new-job3"),
      new StringSelectMenuOptionBuilder()
      .setLabel("ايــدي الـبـلايـسـيـشن")
      .setDescription(`لتعديل ايدي البلايستيشن الخاص بالكاركتر رقم 3 اضغط هنا`)
      .setValue("new-id3")
     )
     const r2 = new ActionRowBuilder().addComponents(select2)
     await i.deferUpdate()
     await i.editReply({components : [r2] , embeds : [emb]})

      }
    })
client.on("interactionCreate" , async  i => {
  if (i.values == "new-name1"){
    const modal = new ModalBuilder()
        .setCustomId("n-m1")
        .setTitle("تغيير الاسم")

        const ques1 = new TextInputBuilder()
.setCustomId("n-name1")
.setStyle(TextInputStyle.Short)
.setLabel("ألاسم الجديد")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

  modal.addComponents(R1)
 await i.showModal(modal)

  }else if (i.values == "new-name2"){
    const modal = new ModalBuilder()
    .setCustomId("n-m2")
    .setTitle("تغيير الاسم")

    const ques1 = new TextInputBuilder()
.setCustomId("n-name2")
.setStyle(TextInputStyle.Short)
.setLabel("ألاسم الجديد")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

modal.addComponents(R1)
await i.showModal(modal)
  }else if (i.values == "new-name3"){
    const modal = new ModalBuilder()
    .setCustomId("n-m3")
    .setTitle("تغيير الاسم")

    const ques1 = new TextInputBuilder()
.setCustomId("n-name3")
.setStyle(TextInputStyle.Short)
.setLabel("ألاسم الجديد")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

modal.addComponents(R1)
await i.showModal(modal)
  }
})
client.on("interactionCreate" , async i => {
  if (!i.isModalSubmit()) return;
if (i.customId == "n-m1"){
  const user = i.user.id
  const newname = i.fields.getTextInputValue("n-name1")
  const words = newname.split(/\s+/)
  if (words.length > 5) {
    return i.reply(`** الرجاء كتابه اسم ثلاثي على الاقل وخماسي كحد اقصى**`)
  }
  if (words.length < 3) {
    return i.reply(`** الرجاء كتابه اسم ثلاثي على الاقل وخماسي كحد اقصى**`)
  }
  const data = db.get(`Character_1_${user}`)
  data.name = (`${newname}`)
  db.set(`Character_1_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 1")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير الاسم 


  الاسم الجديد : ${newname}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}else if (i.customId == "n-m2"){
  if (!i.isModalSubmit()) return;
  const user = i.user.id
  const newname = i.fields.getTextInputValue("n-name2")
  const words = newname.split(/\s+/)
  if (words.length > 5) {
    return i.reply(`** الرجاء كتابه اسم ثلاثي على الاقل وخماسي كحد اقصى**`)
  }
  if (words.length < 3) {
    return i.reply(`** الرجاء كتابه اسم ثلاثي على الاقل وخماسي كحد اقصى**`)
  }
  const data = db.get(`Character_2_${user}`)
  data.name = (`${newname}`)
  db.set(`Character_2_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 2")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير الاسم 


  الاسم الجديد : ${newname}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}else if (i.customId == "n-m3"){
  if (!i.isModalSubmit()) return;
  const user = i.user.id
  const newname = i.fields.getTextInputValue("n-name3")
  const words = newname.split(/\s+/)
  if (words.length > 5) {
    return i.reply(`** الرجاء كتابه اسم ثلاثي على الاقل وخماسي كحد اقصى**`)
  }
  if (words.length < 3) {
    return i.reply(`** الرجاء كتابه اسم ثلاثي على الاقل وخماسي كحد اقصى**`)
  }
  const data = db.get(`Character_3_${user}`)
  data.name = (`${newname}`)
  db.set(`Character_3_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 3")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير الاسم 


  الاسم الجديد : ${newname}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}

})

client.on("interactionCreate" ,async  i => {
  if (i.values == "new-date1"){
      const modal = new ModalBuilder()
      .setCustomId("n-d1")
      .setTitle("تغيير تاريخ الولادة")

      const ques1 = new TextInputBuilder()
.setCustomId("n-date1")
.setStyle(TextInputStyle.Short)
.setLabel("التاريخ الجديد")
.setRequired(true)


const R2 = new ActionRowBuilder().addComponents(ques1)
modal.addComponents(R2)
await i.showModal(modal)

  }else if (i.values == "new-date2"){
    const modal = new ModalBuilder()
    .setCustomId("n-d2")
    .setTitle("تغيير تاريخ الولادة")

    const ques1 = new TextInputBuilder()
.setCustomId("n-date2")
.setStyle(TextInputStyle.Short)
.setLabel("التاريخ الجديد")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

modal.addComponents(R1)
await i.showModal(modal)
  }else if (i.values == "new-date3"){
    const modal = new ModalBuilder()
    .setCustomId("n-d3")
    .setTitle("تغيير تاريخ الولادة")

    const ques1 = new TextInputBuilder()
.setCustomId("n-date3")
.setStyle(TextInputStyle.Short)
.setLabel(" التاريخ الجديد")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

modal.addComponents(R1)
await i.showModal(modal)
  }
})

client.on("interactionCreate" , async i => {
  if (!i.isModalSubmit()) return;
if (i.customId == "n-d1"){
  const user = i.user.id
  const newdaTe1 = i.fields.getTextInputValue("n-date1")
  const time = newdaTe1.split("/")
  const datte = (`${time[2]}${time[1]}${time[0]}`)
if (isNaN(datte)){
return i.reply(`يجب عليك كتابه تاريخ الميلاد بصورة صحيحة 
مثال : \` 1992\\12\\31 \``)
}
  const newdate = (`${time[2]}-${time[1]}-${time[0]}`)
  const data = db.get(`Character_1_${user}`)
  data.newdate = (`${newdaTe1}`)
  db.set(`Character_1_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 1")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير تاريخ الولادة 


  التاريخ الجديد : ${newdaTe1}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}else if (i.customId == "n-d2"){
  if (!i.isModalSubmit()) return;
  const user = i.user.id
  const newdaTe1 = i.fields.getTextInputValue("n-date2")
  const time = newdaTe1.split("/")
  const datte = (`${time[2]}${time[1]}${time[0]}`)
if (isNaN(datte)){
return i.reply(`يجب عليك كتابه تاريخ الميلاد بصورة صحيحة 
مثال : \` 1992\\12\\31 \``)
}
  const data = db.get(`Character_2_${user}`)
  data.newdate = (`${newdaTe1}`)
  db.set(`Character_2_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 2")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير تاريخ الولادة 


  التاريخ الجديد : ${newdaTe1}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}else if (i.customId == "n-d3"){
  if (!i.isModalSubmit()) return;
  const user = i.user.id
  const newdaTe1 = i.fields.getTextInputValue("n-date3")
  const time = newdaTe1.split("/")
  const datte = (`${time[2]}${time[1]}${time[0]}`)
if (isNaN(datte)){
return i.reply(`يجب عليك كتابه تاريخ الميلاد بصورة صحيحة 
مثال : \` 1992\\12\\31 \``)
}
  const data = db.get(`Character_3_${user}`)
  data.newdate = (`${newdaTe1}`)
  db.set(`Character_3_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 3")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير تاريخ الولادة 


  التاريخ الجديد : ${newdaTe1}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}

})

client.on("interactionCreate" , async  i => {
  if (i.values == "new-location1"){
    const modal = new ModalBuilder()
        .setCustomId("n-l1")
        .setTitle("تغيير مكان الولادة")

        const ques1 = new TextInputBuilder()
.setCustomId("n-location1")
.setStyle(TextInputStyle.Short)
.setLabel("المكان الجديد")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

  modal.addComponents(R1)
 await i.showModal(modal)

  }else if (i.values == "new-location2"){
    const modal = new ModalBuilder()
    .setCustomId("n-l2")
    .setTitle("تغيير مكان الولادة")

    const ques1 = new TextInputBuilder()
.setCustomId("n-location2")
.setStyle(TextInputStyle.Short)
.setLabel("المكان الجديد")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

modal.addComponents(R1)
await i.showModal(modal)
  }else if (i.values == "new-location3"){
    const modal = new ModalBuilder()
    .setCustomId("n-l3")
    .setTitle("تغيير مكان الولادة")

    const ques1 = new TextInputBuilder()
.setCustomId("n-location3")
.setStyle(TextInputStyle.Short)
.setLabel("المكان الجديد")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

modal.addComponents(R1)
await i.showModal(modal)
  }
})
client.on("interactionCreate" , async i => {
  if (!i.isModalSubmit()) return;
if (i.customId == "n-l1"){
  const user = i.user.id
  const newlocation = i.fields.getTextInputValue("n-location1")
  if (newlocation !== "لوس سانتوس" && newlocation !== "بوليتو" && newlocation !== "ساندي شور")
      {
          return i.reply(`❌ يجب عليك تحديد احد المدن الاتيه : \n\n \`ساندي شور , بوليتو , لوس سانتوس \``)
      }
  const data = db.get(`Character_1_${user}`)
  data.location = (`${newlocation}`)
  db.set(`Character_1_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 1")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير مكان الولادة 


  المكان الجديد : ${newlocation}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}else if (i.customId == "n-l2"){
  if (!i.isModalSubmit()) return;
  const user = i.user.id
  const newlocation = i.fields.getTextInputValue("n-location2")
  if (newlocation !== "لوس سانتوس" && newlocation !== "بوليتو" && newlocation !== "ساندي شور")
      {
          return i.reply(`❌ يجب عليك تحديد احد المدن الاتيه : \n\n \`ساندي شور , بوليتو , لوس سانتوس \``)
      }
  const data = db.get(`Character_2_${user}`)
  data.location = (`${newlocation}`)
  db.set(`Character_2_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 2")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير مكان الولادة 


  المكان الجديد : ${newlocation}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}else if (i.customId == "n-l3"){
  if (!i.isModalSubmit()) return;
  const user = i.user.id
  const newlocation = i.fields.getTextInputValue("n-location3")
  if (newlocation !== "لوس سانتوس" && newlocation !== "بوليتو" && newlocation !== "ساندي شور")
      {
          return i.reply(`❌ يجب عليك تحديد احد المدن الاتيه : \n\n \`ساندي شور , بوليتو , لوس سانتوس \``)
      }  
  const data = db.get(`Character_3_${user}`)
  data.location = (`${newlocation}`)
  db.set(`Character_3_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 3")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير مكان الولادة 


  المكان الجديد : ${newlocation}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}

})

client.on("interactionCreate" , async  i => {
  if (i.values == "new-job1"){
    const modal = new ModalBuilder()
        .setCustomId("n-j1")
        .setTitle("تغيير الوظيفة ")

        const ques1 = new TextInputBuilder()
.setCustomId("n-job1")
.setStyle(TextInputStyle.Short)
.setLabel("الوظيفة الجديدة")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

  modal.addComponents(R1)
 await i.showModal(modal)

  }else if (i.values == "new-job2"){
    const modal = new ModalBuilder()
    .setCustomId("n-j2")
    .setTitle("تغيير الوظيفة ")

    const ques1 = new TextInputBuilder()
.setCustomId("n-job2")
.setStyle(TextInputStyle.Short)
.setLabel("الوظيفة الجديدة")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

modal.addComponents(R1)
await i.showModal(modal)
  }else if (i.values == "new-job3"){
    const modal = new ModalBuilder()
    .setCustomId("n-j3")
    .setTitle("تغيير الوظيفة ")

    const ques1 = new TextInputBuilder()
.setCustomId("n-job3")
.setStyle(TextInputStyle.Short)
.setLabel("الوظيفة الجديدة")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

modal.addComponents(R1)
await i.showModal(modal)
  }
})
client.on("interactionCreate" , async i => {
  if (!i.isModalSubmit()) return;
if (i.customId == "n-j1"){
  const user = i.user.id
  const newjob = i.fields.getTextInputValue("n-job1")

  const data = db.get(`Character_1_${user}`)
  data.job = (`${newjob}`)
  db.set(`Character_1_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 1")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير الوظيفة  


  الوظيفة الجديدة : ${newjob}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}else if (i.customId == "n-j2"){
  if (!i.isModalSubmit()) return;
  const user = i.user.id
  const newjob = i.fields.getTextInputValue("n-job2")

  const data = db.get(`Character_2_${user}`)
  data.job = (`${newjob}`)
  db.set(`Character_2_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 2")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير الوظيفة  


  الوظيفة الجديدة : ${newjob}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}else if (i.customId == "n-j3"){
  if (!i.isModalSubmit()) return;
  const user = i.user.id
  const newjob = i.fields.getTextInputValue("n-job3")

  const data = db.get(`Character_3_${user}`)
  data.job = (`${newjob}`)
  db.set(`Character_3_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 3")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير الوظيفة  


  الوظيفة الجديدة : ${newjob}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}

})


client.on("interactionCreate" , async  i => {
  if (i.values == "new-id1"){
    const modal = new ModalBuilder()
        .setCustomId("n-i1")
        .setTitle("تغيير الايدي ")

        const ques1 = new TextInputBuilder()
.setCustomId("n-id1")
.setStyle(TextInputStyle.Short)
.setLabel("الايدي الجديد")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

  modal.addComponents(R1)
 await i.showModal(modal)

  }else if (i.values == "new-id2"){
    const modal = new ModalBuilder()
    .setCustomId("n-i2")
    .setTitle("تغيير الايدي ")

    const ques1 = new TextInputBuilder()
.setCustomId("n-id2")
.setStyle(TextInputStyle.Short)
.setLabel("الايدي الجديد")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

modal.addComponents(R1)
await i.showModal(modal)
  }else if (i.values == "new-id3"){
    const modal = new ModalBuilder()
    .setCustomId("n-i3")
    .setTitle("تغيير الايدي ")

    const ques1 = new TextInputBuilder()
.setCustomId("n-id3")
.setStyle(TextInputStyle.Short)
.setLabel("الايدي الجديد")
.setRequired(true)


const R1 = new ActionRowBuilder().addComponents(ques1)

modal.addComponents(R1)
await i.showModal(modal)
  }
})
client.on("interactionCreate" , async i => {
  if (!i.isModalSubmit()) return;
if (i.customId == "n-i1"){
  const user = i.user.id
  const newid = i.fields.getTextInputValue("n-id1")

  const data = db.get(`Character_1_${user}`)
  data.id = (`${newid}`)
  db.set(`Character_1_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 1")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير الايدي  


  الايدي الجديد : ${newid}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}else if (i.customId == "n-i2"){
  if (!i.isModalSubmit()) return;
  const user = i.user.id
  const newid = i.fields.getTextInputValue("n-id2")

  const data = db.get(`Character_2_${user}`)
  data.id = (`${newid}`)
  db.set(`Character_2_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 2")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير الايدي  


  الايدي الجديد : ${newid}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}else if (i.customId == "n-i3"){
  if (!i.isModalSubmit()) return;
  const user = i.user.id
  const newid = i.fields.getTextInputValue("n-id3")

  const data = db.get(`Character_3_${user}`)
  data.id = (`${newid}`)
  db.set(`Character_3_${user}` , data)
  let embed = new EmbedBuilder()
  .setTitle("Character 3")
  .setColor("Green")
  .setThumbnail(i.guild.iconURL())
  .setDescription(`** تم تغيير الايدي  


  الايدي الجديد : ${newid}**`)
  .setAuthor({name : `${i.user.username}` , iconURL : `${i.user.avatarURL()}`})
 i.message.edit({embeds : [embed] , components : []})
 i.reply({content : `# Done ` , ephemeral : true})

}

})
    client.on("messageCreate" , msg => {
      if (msg.content.startsWith(prefix + "set-ch")){
        const user = msg.author;
  const data1 = db.get(`Character_1_${user.id}`)
    const data2 = db.get(`Character_2_${user.id}`)
    const data3 = db.get(`Character_3_${user.id}`)
  if (!data1 && !data2 && !data3){
    return msg.reply("❌ انت لا تمتلك كاركترات")
  }
        const menu = new StringSelectMenuBuilder()
    .setCustomId("select3")
    .setPlaceholder("اضغط هنا ")
    .addOptions(
      new StringSelectMenuOptionBuilder()
      .setLabel("Character 1")
      .setValue("ch-1"),
      new StringSelectMenuOptionBuilder()
      .setLabel("Character 2")
      .setValue("ch-2"),
      new StringSelectMenuOptionBuilder()
      .setLabel("Character 3")
      .setValue("ch-3")
    )
    const row = new ActionRowBuilder().addComponents(menu)
    msg.reply({components : [row]})
      }
    })


client.on("interactionCreate" , async i => {
  if (!i.isSelectMenu())return

  if (i.values[0] === "ch-1"){
    if (!db.has(`Character_1_${i.user.id}`)){
      return i.reply({content : `❌ انت لا تمتلك كاركتر بهذا الرقم` , ephemeral : true})
    }
    if (db.has(`s_${i.user.id}` , `1`))

    return 

    const embed = new EmbedBuilder().setColor("DarkButNotBlack").setTimestamp()
    .setAuthor({name : i.user.username , iconURL : i.user.avatarURL()})
    .setTitle("Selected 1")
    .setDescription("**لقت قمت بتحديد الكاركتر الخاص بك الى الكاركتر رقم 1**")
    await i.deferUpdate()
    await i.editReply({embeds : [embed] , components : [] , content : `${i.user}`})
    if (db.has(`selected_2_${i.user.id}`))
    {
      db.delete(`selected_2_${i.user.id}`)
      db.set(`selected_1_${i.user.id}` , i.user.id)

    }else if (db.has(`selected_3_${i.user.id}`)){
      db.delete(`selected_3_${i.user.id}`)
      db.set(`selected_1_${i.user.id}` , i.user.id)

    }else {
      db.set(`selected_1_${i.user.id}` , i.user.id)

    }
  }else  if (i.values[0] === "ch-2"){
    if (!db.has(`Character_2_${i.user.id}`)){
      return i.reply({content : `❌ انت لا تمتلك كاركتر بهذا الرقم` , ephemeral : true})
    }
    if (db.has(`s_${i.user.id}` , `2`))

    return 

    const embed = new EmbedBuilder().setColor("DarkButNotBlack").setTimestamp()
    .setAuthor({name : i.user.username , iconURL : i.user.avatarURL()})
    .setTitle("Selected 2")
    .setDescription("**لقت قمت بتحديد الكاركتر الخاص بك الى الكاركتر رقم 2**")
    await i.deferUpdate()
    await i.editReply({embeds : [embed] , components : [] , content : `${i.user}`})
    if (db.has(`selected_1_${i.user.id}`))
    {
      db.delete(`selected_1_${i.user.id}`)
      db.set(`selected_2_${i.user.id}` , i.user.id)

    }else if (db.has(`selected_3_${i.user.id}`)){
      db.delete(`selected_3_${i.user.id}`)
      db.set(`selected_2_${i.user.id}` , i.user.id)

    }else{
      db.set(`selected_2_${i.user.id}` , i.user.id)

    } 
   }else  if (i.values[0] === "ch-3"){
    if (!db.has(`Character_3_${i.user.id}`)){
      return i.reply({content : `❌ انت لا تمتلك كاركتر بهذا الرقم` , ephemeral : true})
    }
    if (db.has(`s_${i.user.id}` , `3`))

    return
    const embed = new EmbedBuilder().setColor("DarkButNotBlack").setTimestamp()
    .setAuthor({name : i.user.username , iconURL : i.user.avatarURL()})
    .setTitle("Selected 3")
    .setDescription("**لقت قمت بتحديد الكاركتر الخاص بك الى الكاركتر رقم 3**")
    await i.deferUpdate()
    await i.editReply({embeds : [embed] , components : [] , content : `${i.user}`})
    if (db.has(`selected_2_${i.user.id}`))
    {
      db.delete(`selected_2_${i.user.id}`)
      db.set(`selected_3_${i.user.id}` , i.user.id)

    }else if (db.has(`selected_1_${i.user.id}`)){
      db.delete(`selected_1_${i.user.id}`)
      db.set(`selected_3_${i.user.id}` , i.user.id)

    }else {
      db.set(`selected_3_${i.user.id}` , i.user.id)

    } 
   }
})
client.on("messageCreate" , msg => {
  if (msg.content.startsWith( prefix + "delete-ch")){
    const user = msg.author
const data1 = db.get(`Character_1_${user.id}`)
const data2 = db.get(`Character_2_${user.id}`)
const data3 = db.get(`Character_3_${user.id}`)
if (!data1 && !data2 && !data3){
return msg.reply("❌ انت لا تمتلك كاركترات")
}
    const menu2 = new StringSelectMenuBuilder()
.setCustomId("qw")
.setPlaceholder("اضغط هنا ")
.addOptions(
  new StringSelectMenuOptionBuilder()
  .setLabel("Character 1")
  .setValue("1"),
  new StringSelectMenuOptionBuilder()
  .setLabel("Character 2")
  .setValue("2"),
  new StringSelectMenuOptionBuilder()
  .setLabel("Character 3")
  .setValue("3")
)
const row = new ActionRowBuilder().addComponents(menu2)
msg.reply({components : [row]})
  }
})

client.on("interactionCreate" ,async i => {
if (i.customId == "qw"){
  const p = i.values[0]

if (!db.has(`Character_${p}_${i.user.id}`)){
  return i.reply({content : `❌ انت لا تمتلك كاركتر بهذا الرقم` , ephemeral : true})
}
let row = new ActionRowBuilder().addComponents(
  new ButtonBuilder().setLabel("تأكيد").setCustomId(`${p}`).setStyle(ButtonStyle.Primary),
  new ButtonBuilder().setLabel("الغاء").setCustomId("cancle").setStyle(ButtonStyle.Danger)
)
let embed = new EmbedBuilder().setTimestamp().setColor("DarkButNotBlack").setDescription(`** هل انت متأكد من عمليه حذف كاركتر رقم ${p} **`)
  i.reply({embeds : [embed] , components : [row] , ephemeral : true})

client.on("interactionCreate" ,async i => {
  if (i.customId == `${p}`){
    if (db.has(`Character_${p}_${i.user.id}`)
    ){
      db.delete(`Character_${p}_${i.user.id}`)

  }
    if (db.has(`selected_${p}_${i.user.id}`)){
      db.delete(`selected_${p}_${i.user.id}`)
    }
    let embed2 = new EmbedBuilder().setTimestamp().setColor("DarkButNotBlack")
await i.deferUpdate()
     embed2.setDescription( `** تـم حـذف كـاركـتـر رقـم ${p}**`)
    await i.editReply({embeds : [embed2] , components : []})

  }
})
}else if (i.customId == "cancle"){
i.update({content : `# Done ✅` , embeds : [] , components : [] , ephemeral : true})
}
})

client.on("messageCreate" , msg => {
  if (msg.content.startsWith(prefix + "ch")){
    let user = msg.mentions.members.first() || msg.author;
    const data1 = db.get(`Character_1_${user.id}`)
    const data2 = db.get(`Character_2_${user.id}`)
    const data3 = db.get(`Character_3_${user.id}`)
  if (!data1 && !data2 && !data3){
    return msg.reply("❌ انت لا تمتلك كاركترات")
  }
    if (db.has(`selected_1_${user.id}`)){
      let embed1 = new EmbedBuilder().setColor("Blue").setTimestamp().setTitle("character 1")
      .setThumbnail(data1.attachments)
      .setDescription(`

Name : ${data1.name}


Date : ${data1.newdate}


Place : ${data1.location}


Job : ${data1.job}


PS ID : ${data1.id}


Sex : Male

  `)
      let embed2 = new EmbedBuilder().setColor("DarkButNotBlack").setTimestamp().setTitle("character 1")
      .setThumbnail(data1.attachments)

.setDescription(`
Name : ${data1.name}

Date : ${data1.newdate}

Place : ${data1.location}

Job : ${data1.job}

PS ID : ${data1.id}

Sex : Female`)
if (data1.male === true){
  msg.channel.send({embeds : [embed1]})
}else {
  msg.channel.send({embeds : [embed2]})

}
    }else  if (db.has(`selected_2_${user.id}`)){
      let embed3 = new EmbedBuilder().setColor("Blue").setTimestamp().setTitle("character 2")
      .setThumbnail(data2.attachments)
      .setDescription(`

Name : ${data2.name}


Date : ${data2.newdate}


Place : ${data2.location}


Job : ${data2.job}


PS ID : ${data2.id}


Sex : Male

  `)
      let embed4 = new EmbedBuilder().setColor("DarkButNotBlack").setTimestamp().setTitle("character 2")
      .setThumbnail(data2.attachments)

.setDescription(`
Name : ${data2.name}

Date : ${data2.newdate}

Place : ${data2.location}

Job : ${data2.job}

PS ID : ${data2.id}

Sex : Female`)
if (data2.male === true){
  msg.channel.send({embeds : [embed3]})
}else {
  msg.channel.send({embeds : [embed4]})

}
    }else  if (db.has(`selected_3_${user.id}`)){
      let embed5 = new EmbedBuilder().setColor("Blue").setTimestamp().setTitle("character 3")
      .setThumbnail(data3.attachments)
      .setDescription(`

Name : ${data3.name}


Date : ${data3.newdate}


Place : ${data3.location}


Job : ${data3.job}


PS ID : ${data3.id}


Sex : Male

  `)
      let embed6 = new EmbedBuilder().setColor("DarkButNotBlack").setTimestamp().setTitle("character 3")
      .setThumbnail(data3.attachments)

.setDescription(`
Name : ${data3.name}

Date : ${data3.newdate}

Place : ${data3.location}

Job : ${data3.job}

PS ID : ${data3.id}

Sex : Female`)
if (data3.male === true){
  msg.channel.send({embeds : [embed5]})
}else {
  msg.channel.send({embeds : [embed6]})

}
    }else {
      msg.reply(`انت لم تقم بتحديد الكاركتر الخاص بك`)
    }
  }
})


client.login(process.env.token)